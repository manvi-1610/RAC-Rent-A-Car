package com.example.rac.utils;

public class Constants {

    public static String SHARED_PREFS = "RAC_SHARED_PREFS";
    public static String SHARED_PREFS_USER_EMAIL = "RAC_USER_EMAIL";
}
