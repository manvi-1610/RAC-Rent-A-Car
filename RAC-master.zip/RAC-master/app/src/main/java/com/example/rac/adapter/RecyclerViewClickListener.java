package com.example.rac.adapter;

public interface RecyclerViewClickListener {
    void OnItemClick(int position);
}
